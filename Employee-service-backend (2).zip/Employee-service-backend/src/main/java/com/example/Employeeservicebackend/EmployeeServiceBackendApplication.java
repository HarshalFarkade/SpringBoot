package com.example.Employeeservicebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeServiceBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeServiceBackendApplication.class, args);
		System.out.println("EmployeeService");
	}

}
